To run the program, run the following line (in the same directory as the Project1.py file):
'python Project1.py 127.0.0.1'

- 'python' may differ based on your version of python and your personal path/environment variables.
- The server socket is currently hard-coded to run on 127.0.0.1, with port 8000.

Notable Issues for Grading:
- The 'POST' request was unsolved, and as a result was removed from the code.
-> (I was unsure of where to place it, and only found one example of how to write it)
- Errors will only list what is available to 'except Exception as e', and are not well specified
- The '301' error is unhandled. 

Otherwise, I believe all other functionality to be intact.
Comments have been made at each 'fill in' area of the provided skeleton code. 
Screenshots of successful interaction have been attached. 